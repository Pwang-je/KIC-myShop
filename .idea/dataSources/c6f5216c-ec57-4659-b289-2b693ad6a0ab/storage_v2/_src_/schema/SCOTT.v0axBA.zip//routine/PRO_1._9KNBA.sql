create procedure pro_1(name in person.name%type, weight in person.weight%type)
is
begin
  insert into person values(seq_id.nextval, name,weight);
  commit;
exception when others then
  dbms_output.put_line('insert error!');
  rollback;
end;
/

