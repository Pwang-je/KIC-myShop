create procedure p_c(no in jiktest.jikwon_no%type)
is 
begin
  delete from jiktest
          where jikwon_no=no;
end;
/

