create procedure pro_7
is
  cursor cur is
                select buser_name, sum(jikwon_pay) tot, count(*) cnt
                from   jikwon inner join buser on buser_num=buser_no
                group by buser_name;
begin

  for jiklist in cur loop
    dbms_output.put_line(jiklist.buser_name);
    dbms_output.put_line(jiklist.tot);
    dbms_output.put_line(jiklist.cnt);

  end loop;
  exception when others then
    dbms_output.put_line('error!');
end;
/

