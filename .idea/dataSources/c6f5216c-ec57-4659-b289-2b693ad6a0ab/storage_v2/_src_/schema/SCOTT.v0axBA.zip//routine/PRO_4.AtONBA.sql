create procedure pro_4(vid in person.id%type)
is
  pid person.id%type;
  pname person.name%type;
  pweight person.weight%type;
begin
  select * into pid,pname,pweight from person where id=vid;
  dbms_output.put_line(pid || ' ' || pname || ' ' || pweight );
  commit;
exception when others then
  dbms_output.put_line('delete error!');
end;
/

